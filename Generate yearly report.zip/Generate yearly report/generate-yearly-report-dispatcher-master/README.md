# Generate Yearly Report - Dispatcher

## Description

UiPath Academy project concerned on implementing Robotic Enterprise Framework.

## Contributions

Based on video series:
1. [Generate Yearly Report - Dispatcher Part 1 | UiPath Level 3 Exercise](https://www.youtube.com/watch?v=thGZkHaYmIY)
2. [Generate Yearly Report - Dispatcher Part 2 | UiPath Level 3 Exercise](https://www.youtube.com/watch?v=obSZqT6m_9E)

## Software

* UiPath Studio v2019.12.0-beta.61 Community License
* UiPath Robot v19.12.0